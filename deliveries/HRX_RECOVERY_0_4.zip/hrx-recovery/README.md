# HRX-OS 恢复工程 0.4

这是 2026-11-17 根据本对话可见代码与业务契约重建的独立开发工程，**不是原 V19.5 压缩包的完整恢复**。原 V001–V014、确认版HTML、旧模块全部源码和原测试证据已不可取得；不能声称原文件哈希或旧测试仍有效。

优先重建采购/PMC、JWT身份、服务端权限/RLS、幂等/并发、受控文件及可运行界面。原项目交付、工程支持、成长、呆滞料、ECN/NCR/FAT/SAT完整模块继续列为缺失，不创建空壳入口或伪造经营数据。

本工程采用新的数据库基线，**只用于新的隔离数据库**，不得覆盖旧系统数据库。详见 docs/RECOVERY.md。所有实际测试结果另行记录，不沿用之前的33/37通过声明。

当前检查点的真实验证见 docs/VALIDATION.md。源码已放入当前挂载仓库子目录 hrx-recovery，本地Git分支 recovery/hrx-20261117；不再只放临时目录。

开发：JDK21、Maven3.9+、Node>=22.12、PostgreSQL16+。前端 npm ci / npm test / npm run build；后端使用全新隔离数据库引导角色后运行 mvn verify。真实数据库测试须设置 HRX_TEST_DB_URL，数据库名必须以 hrx_test_ 开头；HRX_BROWSER=true启用Chromium脚本。企业OIDC仍由部署壳注入HRX_AUTH，不存在时默认拒绝业务操作。

最新完整隔离验证：36个JUnit、15个Node测试、五组浏览器实测、生产构建和数据库结构/授权恢复演练通过。ClamAV仅使用TEST签名库。运行与复现见 docs/OPERATIONS.md，接口见 docs/API.md；完整恢复缺失项仍见 docs/RECOVERY.md。


0.2新增拒收退货与补货闭环，见 docs/RETURNS.md。采购主链与文件服务均为新恢复工程；原旧版模块缺失项继续明确保留。0.1/0.2/0.3/0.4源码包、逐文件SHA256清单和外部校验文件保存在仓库deliveries/；公开备份已获得用户同意，源代码未合并main。

0.3新增同项目／供应商／币种的多行订单、需求预留、整单独立审批与原子下单、订单专属受控证据，见 docs/PURCHASE_ORDERS.md。价格数值以精确十进制字符串返回。

0.4新增订单履约跟踪与项目齐套总览，支持逐行收退货/待检/拒收/补货缺口、重叠风险统计与需求处理跳转，见 docs/DELIVERY_READINESS.md。遵照用户最新指示，按HRX_OS_CODEX_HANDOFF_V19_4方向持续开发，不等待缺失原文件。
